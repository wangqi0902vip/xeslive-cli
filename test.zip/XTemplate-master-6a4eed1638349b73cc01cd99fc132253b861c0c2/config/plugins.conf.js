module.exports = {
  plugins:['pixi-spine','matter-js','http-server']
}
